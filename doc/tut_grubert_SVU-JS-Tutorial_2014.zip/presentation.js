//------------------------------------------------------------------------------
// Variables
var a = 10;
var b = "Hello";
var c = true;
var d = new Object();
var e = function () { };

console.log("a: " + a + " " + typeof a);
console.log("b: " + b + " " + typeof b);
console.log("c: " + c + " " + typeof c);
console.log("d: " + d + " " + typeof d);
console.log("e: " + e + " " + typeof e);

//------------------------------------------------------------------------------
// Functions
function f1() { alert("This is function f1"); }
var f2 = function () { alert("function f2"); }
var f3 = function (arg1) { alert(arg1 * arg1); }

f1();
f2();
f3(7);

function g() {
    setTimeout(function () { alert("executed after 2 seconds") }, 2000);
}

g();

//------------------------------------------------------------------------------
//Functions as Parameter
function callback() { console.log("callback") }

function h(param1, callback_function) {
    //do something
    console.log("working...");
    callback_function();
}

h("foo", callback);

//------------------------------------------------------------------------------
//if-else
var x = 42;

if (x > 10) {
    console.log("x > 10");
} else if (x < 5) {
    console.log("x < 5");
} else {
    console.log("x: 5-10");
}

//------------------------------------------------------------------------------
//switch-case
var y = 7;
switch (y) {
    case 8:
        console.log("yeah 8...");
        break;
    case 0:
        console.log("oh, 0");
        break;
    default:
        console.log("hmm...");
}

//------------------------------------------------------------------------------
//while
var x = 5;
while (x > 0) {
    console.log(x--);
}

//------------------------------------------------------------------------------
//do-while
var x = 7;
do {
    console.log(x++);
} while (x < 10);

//------------------------------------------------------------------------------
//for
for (var i = 0; i < 3; i++) {
    console.log(i);
}

var obj = [1, 2, 3, 4];
for (key in obj) {
    console.log(obj[key]);
}

//------------------------------------------------------------------------------
//Try-catch
function tryCatchExample(func) {
    try {
        func();
    } catch (e) { //called if an error occured
        console.log("an error occured");
    } finally { //always called at the end of the try or catch block
        console.log("called at the end");
    }
}

function failingFunc() {
    throw "some exception";
}

function okFunc() {
    console.log("I'm ok");
}

tryCatchExample(failingFunc);
tryCatchExample(okFunc);

//------------------------------------------------------------------------------
//Objects
var container = new Object();
container.prop1 = "Hey";
container.method1 = function () {
    console.log("container.prop1: " + container.prop1);
}

container.method1();

var container = {
    prop2: "Hello",
    method2: function () {
        console.log("container.prop2: " + container.prop2);
    }
};
container.method2();
console.log(container.prop2);
console.log(container["prop2"]);

//------------------------------------------------------------------------------
//Arrays
var array = new Array();
array.push(10); //adds element 10
array.push("string");
array.push(22);
console.log(array);
console.log(array[1]);
console.log(array['1']);
array.pop(); //removes '22' (last element)
console.log(array);

var array = [];
for (var i = 0; i < 10; i++)
    array.push(i);
array.splice(5, 1); //removes element 5

//iteration
for (var i = 0; i < array.length; i++)
    console.log(array[i]);

for (key in array)
    console.log(array[key]);

array.forEach(function (ele) {
    console.log(ele);
});

//------------------------------------------------------------------------------
//Prototypes
var person = {};
var joe = Object.create(person);
console.log(joe.kind); // => undefined

// new properties are inherited
person.kind = 'person';
console.log(joe.kind); // => "person";

// updated properties are assigned to the object
joe.kind = 'dude';
console.log(joe.kind); // => "dude";
console.log(person.kind); // => "person";

// query the prototype object
console.log(Object.getPrototypeOf(joe)); // => person;

// assign a new prototype to joe
var alien = { kind: "alien" };
var joe = Object.create(alien);
console.log(Object.getPrototypeOf(joe)); // => alien;

//------------------------------------------------------------------------------
//Prototypes - Constructor functions
function Person(name) {
    this.name = name;
}
// create a new object using *new*
var joe = new Person("joe"); // var jane = Person("jane"); // does not work
console.log(joe.kind); //=> undefined

// the function Person has a prototype property
// we can add properties to this function prototype
Person.prototype.kind = "person";
// in the new object we have access to properties defined in Person.prototype
console.log(joe.kind); //=> person

Person.nLegs = 2; // this does not work, as we can not assign the property to the function itself
console.log(joe.nLegs);  //=> undefined

joe.nLegs = 2; // works as we now deal with an object and not with a function
console.log(joe.nLegs);  //=> 2

//slides:
function Person(name) {
    this.name = name;
}
var joe = new Person("joe");

Person.nLegs = 2; // does not work
console.log(joe.nLegs); //=> undefined

joe.nLegs = 2;
console.log(joe.nLegs); //=> 2

//------------------------------------------------------------------------------
//Closures
var closure = (function () {
    var priv_var = "secret";                //no outside access
    function priv_func() {
        console.log("private function");
    }
    return {                                //outside access
        pub_var: "public",
        pub_func: function () {
            console.log("priv_var: " + priv_var);
        },
    };
})();

console.log("priv_var: " + closure.priv_var);
closure.priv_func(); //not working this way!
console.log("pub_var: " + closure.pub_var);
closure.pub_func();

//------------------------------------------------------------------------------
//node.js examples

//read a file:
var myfile = fs.readFile('myfile.txt', 'utf8');
console.log(myfile);
console.log('Finished!');

fs.readFile('myfile.txt', 'utf8', function (err, data) {
    if (err) throw err;
    console.log(data);
});
console.log('Finished reading file!');

//simple webserver
var http = require('http');
var server = http.createServer(function (req, res) {
    res.writeHead(200);
    res.end('Hello Http');
});
server.listen(8080);
//open a browser and open localhost:8080
